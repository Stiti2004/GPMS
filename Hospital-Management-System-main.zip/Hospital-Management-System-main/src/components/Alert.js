import React from 'react'


export default function Alert(props) {



    return (
        <div className='mt-2' style={{ height: '50px' }}>

            {/* {props.alert && <div className='container'>
                <div className={`alert alert-${props.alert.type==="success"?"success":"danger"} alert-dismissible fade show`} role="alert">
                    <strong>{props.alert.message}</strong>
                </div>
            </div>} */}
        </div>
    )
}